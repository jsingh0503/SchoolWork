# Final Exam

The instructions are detailed in main.cpp.
Open main.cpp in your favorite C++ IDE (Visual Studio, XCode, etc.) and follow the instructions.
Once completed, commit your changes.
